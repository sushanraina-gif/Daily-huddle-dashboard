import { kv } from '@vercel/kv';

export const config = { api: { bodyParser: { sizeLimit: '10mb' } } };

const UPLOAD_SECRET = process.env.UPLOAD_SECRET || 'cars24-upload-2024';

export default async function handler(req, res) {
  // CORS headers so the dashboard HTML can call this from any origin
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-upload-secret');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  // Simple secret check so random people can't overwrite your data
  const secret = req.headers['x-upload-secret'];
  if (secret !== UPLOAD_SECRET) {
    return res.status(401).json({ error: 'Invalid upload secret' });
  }

  try {
    const { rows, filename } = req.body;

    if (!rows || !Array.isArray(rows) || rows.length === 0) {
      return res.status(400).json({ error: 'No rows provided' });
    }

    // Store rows + metadata
    await kv.set('dashboard_data', {
      rows,
      filename: filename || 'unknown',
      uploadedAt: new Date().toISOString(),
      rowCount: rows.length,
    });

    return res.status(200).json({
      ok: true,
      rowCount: rows.length,
      filename,
      uploadedAt: new Date().toISOString(),
    });

  } catch (err) {
    console.error('Upload error:', err);
    return res.status(500).json({ error: err.message });
  }
}
