import { useEffect } from 'react';

export default function Home() {
  useEffect(() => {
    // Redirect to the static dashboard
    window.location.replace('/dashboard.html');
  }, []);
  return null;
}
